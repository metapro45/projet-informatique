package config

import (
	"fmt"
	"os"
)

// Config regroupe toutes les variables d'environnement nécessaires au serveur.
// Chargée une seule fois au démarrage via LoadConfig().
type Config struct {
	// Serveur
	Port string // ex: "8080"

	// Supabase — Base de données
	DBHost     string // ex: "db.<ref>.supabase.co"
	DBPort     string // ex: "5432"
	DBUser     string // ex: "postgres"
	DBPassword string // ⚠️  Ne jamais committer en clair
	DBName     string // ex: "postgres"

	// Supabase — Auth
	SupabaseURL    string // ex: "https://<ref>.supabase.co"
	SupabaseAnonKey string // Clé publique anon (safe côté client)
	JWTSecret      string // ⚠️  JWT secret Supabase (Settings > API)

	// Supabase — Storage
	// TODO Étape 6 : Ajouter StorageBucket string
}

// LoadConfig charge la configuration depuis les variables d'environnement.
// Retourne une erreur si une variable obligatoire est absente.
func LoadConfig() (*Config, error) {
	cfg := &Config{
		Port:            getEnv("PORT", "8080"),
		DBHost:          getEnv("DB_HOST", ""),
		DBPort:          getEnv("DB_PORT", "5432"),
		DBUser:          getEnv("DB_USER", "postgres"),
		DBPassword:      getEnv("DB_PASSWORD", ""),
		DBName:          getEnv("DB_NAME", "postgres"),
		SupabaseURL:     getEnv("SUPABASE_URL", ""),
		SupabaseAnonKey: getEnv("SUPABASE_ANON_KEY", ""),
		JWTSecret:       getEnv("SUPABASE_JWT_SECRET", ""),
	}

	// Validation des variables obligatoires
	required := map[string]string{
		"DB_HOST":            cfg.DBHost,
		"DB_PASSWORD":        cfg.DBPassword,
		"SUPABASE_URL":       cfg.SupabaseURL,
		"SUPABASE_JWT_SECRET": cfg.JWTSecret,
	}
	for key, val := range required {
		if val == "" {
			return nil, fmt.Errorf("config: variable d'environnement obligatoire manquante : %s", key)
		}
	}

	return cfg, nil
}

// DSN construit la chaîne de connexion PostgreSQL pour database.Connect().
func (c *Config) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=require",
		c.DBHost, c.DBPort, c.DBUser, c.DBPassword, c.DBName,
	)
}

// getEnv retourne la valeur d'une variable d'environnement ou une valeur par défaut.
func getEnv(key, defaultVal string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return defaultVal
}
