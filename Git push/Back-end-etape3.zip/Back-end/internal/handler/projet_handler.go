package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// ProjetHandler regroupe les handlers HTTP pour la ressource Projet.
// Chaque méthode correspond à un endpoint du contrat d'API (§2).
//
// TODO Étape 4 : Implémenter chaque handler avec la logique métier complète.
type ProjetHandler struct {
	db *sql.DB
}

// NewProjetHandler crée un ProjetHandler avec la connexion BDD injectée.
func NewProjetHandler(db *sql.DB) *ProjetHandler {
	return &ProjetHandler{db: db}
}

// GetAll godoc
// @Summary  Lister tous les projets
// @Route    GET /api/projets
// @Roles    etudiant | enseignant
func (h *ProjetHandler) GetAll(c *fiber.Ctx) error {
	// TODO Étape 4
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false,
		"error":   "GET /api/projets — non implémenté (Étape 4)",
	})
}

// Create godoc
// @Summary  Créer un projet
// @Route    POST /api/projets
// @Roles    enseignant
func (h *ProjetHandler) Create(c *fiber.Ctx) error {
	// TODO Étape 4
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false,
		"error":   "POST /api/projets — non implémenté (Étape 4)",
	})
}

// GetByID godoc
// @Summary  Voir un projet
// @Route    GET /api/projets/:id
// @Roles    etudiant | enseignant
func (h *ProjetHandler) GetByID(c *fiber.Ctx) error {
	// TODO Étape 4
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false,
		"error":   "GET /api/projets/:id — non implémenté (Étape 4)",
	})
}

// Update godoc
// @Summary  Modifier un projet
// @Route    PUT /api/projets/:id
// @Roles    enseignant
func (h *ProjetHandler) Update(c *fiber.Ctx) error {
	// TODO Étape 4
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false,
		"error":   "PUT /api/projets/:id — non implémenté (Étape 4)",
	})
}

// Delete godoc
// @Summary  Supprimer un projet
// @Route    DELETE /api/projets/:id
// @Roles    enseignant
func (h *ProjetHandler) Delete(c *fiber.Ctx) error {
	// TODO Étape 4
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false,
		"error":   "DELETE /api/projets/:id — non implémenté (Étape 4)",
	})
}
