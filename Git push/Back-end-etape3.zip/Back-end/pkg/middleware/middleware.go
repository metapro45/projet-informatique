package middleware

import (
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
)

// ContextUserID est la clé utilisée pour stocker l'UUID de l'utilisateur
// dans le contexte Fiber après validation du JWT.
// Utilisée dans les handlers : c.Locals(middleware.ContextUserID)
const ContextUserID   = "user_id"

// ContextUserRole est la clé pour stocker le rôle extrait du JWT.
// Valeurs possibles : "etudiant" | "enseignant"
const ContextUserRole = "user_role"

// ContextUserEmail est la clé pour stocker l'email extrait du JWT.
const ContextUserEmail = "user_email"

// supabaseClaims représente la structure des claims dans un JWT Supabase.
// Supabase inclut des champs standards JWT + des champs custom dans "user_metadata".
type supabaseClaims struct {
	// Champs JWT standards
	Subject  string `json:"sub"`   // UUID de l'utilisateur
	Email    string `json:"email"` // Email de l'utilisateur

	// Champs Supabase spécifiques
	Role     string `json:"role"`  // "anon" ou "authenticated"

	// Métadonnées utilisateur (stockées lors de l'inscription)
	UserMetadata struct {
		Role string `json:"role"` // "etudiant" | "enseignant"
	} `json:"user_metadata"`

	// AppMetadata (géré par Supabase, plus fiable pour les rôles admin)
	AppMetadata struct {
		Role string `json:"role"`
	} `json:"app_metadata"`

	jwt.RegisteredClaims
}

// JWTProtected retourne un middleware Fiber qui vérifie le token JWT Supabase.
//
// Comportement :
//  1. Extrait le token depuis le header "Authorization: Bearer <token>"
//  2. Valide la signature avec le JWT Secret Supabase
//  3. Stocke user_id, user_role et user_email dans le contexte Fiber
//  4. Retourne 401 si le token est absent, malformé ou expiré
//
// Usage dans routes.go :
//
//	api := app.Group("/api", middleware.JWTProtected(cfg.JWTSecret))
func JWTProtected(jwtSecret string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		// ── 1. Extraire le token du header ────────────────────────────────────
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT manquant — header Authorization requis",
			})
		}

		// Vérifier le format "Bearer <token>"
		parts := strings.SplitN(authHeader, " ", 2)
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Format invalide — attendu : Authorization: Bearer <token>",
			})
		}
		tokenString := parts[1]

		// ── 2. Parser et valider le token ─────────────────────────────────────
		claims := &supabaseClaims{}
		token, err := jwt.ParseWithClaims(
			tokenString,
			claims,
			func(token *jwt.Token) (interface{}, error) {
				// Vérifier que l'algorithme est bien HMAC (HS256)
				if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
					return nil, fiber.NewError(fiber.StatusUnauthorized,
						"Algorithme de signature JWT invalide")
				}
				return []byte(jwtSecret), nil
			},
		)

		if err != nil || !token.Valid {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT invalide ou expiré — veuillez vous reconnecter",
			})
		}

		// ── 3. Extraire le rôle applicatif ────────────────────────────────────
		// Priorité : user_metadata.role > app_metadata.role
		// C'est le rôle métier ("etudiant" | "enseignant"), pas le rôle Supabase
		userRole := claims.UserMetadata.Role
		if userRole == "" {
			userRole = claims.AppMetadata.Role
		}
		// Fallback : si aucun rôle métier, on met "etudiant" par défaut
		if userRole == "" {
			userRole = "etudiant"
		}

		// ── 4. Stocker dans le contexte Fiber ─────────────────────────────────
		c.Locals(ContextUserID,    claims.Subject) // UUID Supabase Auth
		c.Locals(ContextUserRole,  userRole)
		c.Locals(ContextUserEmail, claims.Email)

		return c.Next()
	}
}

// RequireRole retourne un middleware qui vérifie que l'utilisateur a le rôle requis.
// Doit être utilisé APRÈS JWTProtected (qui peuple les Locals).
//
// Usage :
//
//	projets.Post("/", middleware.RequireRole("enseignant"), projetH.Create)
func RequireRole(roles ...string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		userRole, ok := c.Locals(ContextUserRole).(string)
		if !ok || userRole == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Rôle utilisateur non trouvé — token invalide",
			})
		}

		// Vérifier si le rôle de l'utilisateur est dans la liste autorisée
		for _, role := range roles {
			if userRole == role {
				return c.Next()
			}
		}

		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"success": false,
			"error":   "Accès refusé — rôle insuffisant",
			"detail": fiber.Map{
				"role_actuel":  userRole,
				"roles_requis": roles,
			},
		})
	}
}

// GetUserID est un helper pour extraire l'UUID de l'utilisateur connecté
// depuis le contexte Fiber dans un handler.
//
// Usage dans un handler :
//
//	userID := middleware.GetUserID(c)
func GetUserID(c *fiber.Ctx) string {
	id, _ := c.Locals(ContextUserID).(string)
	return id
}

// GetUserRole est un helper pour extraire le rôle de l'utilisateur connecté.
func GetUserRole(c *fiber.Ctx) string {
	role, _ := c.Locals(ContextUserRole).(string)
	return role
}
