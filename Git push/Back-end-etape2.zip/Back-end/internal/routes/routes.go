package routes

import (
	"database/sql"
	"fmt"

	"github.com/gofiber/fiber/v2"

	"suivi-projets-backend/internal/handler"
)

// Register déclare toutes les routes de l'API et les associe à leurs handlers.
// Appelée une seule fois au démarrage depuis cmd/server/main.go.
//
// Convention d'URL : imbriquée (Option 1 validée équipe)
// Middleware JWT : TODO Étape 3 — toutes les routes sous /api sont protégées.
func Register(app *fiber.App, db *sql.DB) {

	// ── Instanciation des handlers ─────────────────────────────────────────────
	projetH   := handler.NewProjetHandler(db)
	equipeH   := handler.NewEquipeHandler(db)
	membreH   := handler.NewMembreHandler(db)
	tacheH    := handler.NewTacheHandler(db)
	jalonH    := handler.NewJalonHandler(db)
	livrableH := handler.NewLivrableHandler(db)

	// ── Groupe principal /api ──────────────────────────────────────────────────
	api := app.Group("/api")

	// ════════════════════════════════════════════════════════════════════════════
	// HEALTH CHECKS — endpoints de diagnostic (publics, sans JWT)
	// ════════════════════════════════════════════════════════════════════════════

	// /health — vérifie que Fiber tourne
	api.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"success": true,
			"data": fiber.Map{
				"status":  "ok",
				"version": "1.0.0",
				"etape":   "2 — Boilerplate Fiber",
			},
		})
	})

	// /health/db — vérifie la connexion PostgreSQL (T24)
	api.Get("/health/db", func(c *fiber.Ctx) error {
		if db == nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"success": false,
				"error":   "Base de données non connectée (mode dégradé)",
			})
		}

		var now string
		if err := db.QueryRowContext(c.Context(), "SELECT NOW()::text").Scan(&now); err != nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"success": false,
				"error":   fmt.Sprintf("Requête SQL échouée : %v", err),
			})
		}

		var tableCount int
		db.QueryRowContext(c.Context(), `
			SELECT COUNT(*) FROM information_schema.tables
			WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
		`).Scan(&tableCount)

		rows, err := db.QueryContext(c.Context(), `
			SELECT table_name FROM information_schema.tables
			WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
			ORDER BY table_name
		`)
		if err != nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"success": false, "error": err.Error(),
			})
		}
		defer rows.Close()

		tables := []string{}
		for rows.Next() {
			var t string
			if rows.Scan(&t) == nil {
				tables = append(tables, t)
			}
		}

		return c.JSON(fiber.Map{
			"success": true,
			"data": fiber.Map{
				"status":      "connecté",
				"server_time": now,
				"tables":      tableCount,
				"schema":      tables,
			},
		})
	})

	// /health/indexes — vérifie les index créés par M3 (T13)
	api.Get("/health/indexes", func(c *fiber.Ctx) error {
		if db == nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"success": false, "error": "Base de données non connectée",
			})
		}

		rows, err := db.QueryContext(c.Context(), `
			SELECT
				i.relname AS index_name,
				t.relname AS table_name,
				array_to_string(array_agg(a.attname ORDER BY k.n), ', ') AS colonnes,
				ix.indisunique  AS est_unique,
				ix.indisprimary AS est_primaire
			FROM pg_class t
				JOIN pg_index ix ON t.oid = ix.indrelid
				JOIN pg_class i  ON i.oid = ix.indexrelid
				JOIN pg_namespace n ON n.oid = t.relnamespace
				JOIN LATERAL unnest(ix.indkey) WITH ORDINALITY AS k(attnum, n) ON TRUE
				JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = k.attnum
			WHERE n.nspname = 'public' AND t.relkind = 'r'
			GROUP BY i.relname, t.relname, ix.indisunique, ix.indisprimary
			ORDER BY t.relname, ix.indisprimary DESC, i.relname
		`)
		if err != nil {
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
				"success": false, "error": fmt.Sprintf("Requête index échouée : %v", err),
			})
		}
		defer rows.Close()

		type IndexInfo struct {
			Nom      string `json:"nom"`
			Table    string `json:"table"`
			Colonnes string `json:"colonnes"`
			Unique   bool   `json:"unique"`
			Primaire bool   `json:"primaire"`
		}

		indexes := []IndexInfo{}
		for rows.Next() {
			var idx IndexInfo
			if rows.Scan(&idx.Nom, &idx.Table, &idx.Colonnes, &idx.Unique, &idx.Primaire) == nil {
				indexes = append(indexes, idx)
			}
		}

		indexFKCount := 0
		for _, idx := range indexes {
			if !idx.Primaire {
				indexFKCount++
			}
		}

		return c.JSON(fiber.Map{
			"success": true,
			"data": fiber.Map{
				"total_index":      len(indexes),
				"index_fk_manuels": indexFKCount,
				"t13_valide":       indexFKCount > 0,
				"detail":           indexes,
			},
		})
	})

	// /health/schema — inspecte la structure réelle de chaque table (audit cohérence)
	// Utilisé pour comparer le schéma BDD avec nos structs Go
	api.Get("/health/schema", func(c *fiber.Ctx) error {
		if db == nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"success": false, "error": "Base de données non connectée",
			})
		}

		rows, err := db.QueryContext(c.Context(), `
			SELECT
				table_name,
				column_name,
				data_type,
				is_nullable,
				column_default
			FROM information_schema.columns
			WHERE table_schema = 'public'
			ORDER BY table_name, ordinal_position
		`)
		if err != nil {
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
				"success": false, "error": err.Error(),
			})
		}
		defer rows.Close()

		type Col struct {
			Colonne  string  `json:"colonne"`
			Type     string  `json:"type"`
			Nullable string  `json:"nullable"`
			Default  *string `json:"default,omitempty"`
		}

		schema := map[string][]Col{}
		for rows.Next() {
			var tableName string
			var col Col
			if rows.Scan(&tableName, &col.Colonne, &col.Type, &col.Nullable, &col.Default) == nil {
				schema[tableName] = append(schema[tableName], col)
			}
		}

		return c.JSON(fiber.Map{
			"success": true,
			"data":    schema,
		})
	})

	// ════════════════════════════════════════════════════════════════════════════
	// §2 — PROJETS
	// Contrat d'API : sections 2.1 à 2.5
	// ════════════════════════════════════════════════════════════════════════════
	projets := api.Group("/projets")
	projets.Get("/",       projetH.GetAll)
	projets.Post("/",      projetH.Create)
	projets.Get("/:id",    projetH.GetByID)
	projets.Put("/:id",    projetH.Update)
	projets.Delete("/:id", projetH.Delete)

	// ════════════════════════════════════════════════════════════════════════════
	// §3 — ÉQUIPES
	// Contrat d'API : sections 3.1 à 3.4
	// ════════════════════════════════════════════════════════════════════════════
	projets.Get("/:id/equipes",  equipeH.GetByProjet)
	projets.Post("/:id/equipes", equipeH.Create)

	equipes := api.Group("/equipes")
	equipes.Put("/:id",    equipeH.Update)
	equipes.Delete("/:id", equipeH.Delete)

	// ════════════════════════════════════════════════════════════════════════════
	// §4 — MEMBRES
	// Contrat d'API : sections 4.1 à 4.3
	// ════════════════════════════════════════════════════════════════════════════
	equipes.Get("/:id/membres",             membreH.GetByEquipe)
	equipes.Post("/:id/membres",            membreH.Add)
	equipes.Delete("/:id/membres/:user_id", membreH.Remove)

	// ════════════════════════════════════════════════════════════════════════════
	// §5 — TÂCHES (KANBAN)
	// Contrat d'API : sections 5.1 à 5.5
	// ════════════════════════════════════════════════════════════════════════════
	equipes.Get("/:id/taches",  tacheH.GetByEquipe)
	equipes.Post("/:id/taches", tacheH.Create)

	taches := api.Group("/taches")
	taches.Patch("/:id/statut", tacheH.UpdateStatut)
	taches.Patch("/:id",        tacheH.Update)
	taches.Delete("/:id",       tacheH.Delete)

	// ════════════════════════════════════════════════════════════════════════════
	// §6 — JALONS
	// Contrat d'API : sections 6.1 à 6.4
	// ════════════════════════════════════════════════════════════════════════════
	projets.Get("/:id/jalons",  jalonH.GetByProjet)
	projets.Post("/:id/jalons", jalonH.Create)

	jalons := api.Group("/jalons")
	jalons.Put("/:id",    jalonH.Update)
	jalons.Delete("/:id", jalonH.Delete)

	// ════════════════════════════════════════════════════════════════════════════
	// §7 — LIVRABLES
	// Contrat d'API : sections 7.1 à 7.4
	// ════════════════════════════════════════════════════════════════════════════
	jalons.Get("/:id/livrables",   livrableH.GetByJalon)
	equipes.Post("/:id/livrables", livrableH.Create)

	livrables := api.Group("/livrables")
	livrables.Patch("/:id/note", livrableH.Noter)
	livrables.Delete("/:id",     livrableH.Delete)
}
