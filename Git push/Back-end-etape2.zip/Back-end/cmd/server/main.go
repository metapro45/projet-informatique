package main

import (
	"log"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"

	"suivi-projets-backend/config"
	"suivi-projets-backend/pkg/database"
	"suivi-projets-backend/internal/routes"
)

// main est le point d'entrée du serveur.
//
// Séquence de démarrage :
//  1. Charger la configuration depuis .env
//  2. Connecter la base de données PostgreSQL (Supabase)
//  3. Initialiser le serveur Fiber avec ses middlewares globaux
//  4. Enregistrer toutes les routes de l'API
//  5. Démarrer l'écoute HTTP sur le port configuré
//
// TODO Étape 3 : Brancher le middleware JWT (pkg/middleware/middleware.go)
func main() {
	// ── 1. Configuration ───────────────────────────────────────────────────────
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("❌ Erreur de configuration : %v", err)
	}
	log.Println("✅ Configuration chargée")

	// ── 2. Connexion base de données ───────────────────────────────────────────
	if err := database.Connect(cfg.DSN()); err != nil {
		log.Fatalf("❌ Connexion BDD échouée : %v", err)
	}

	// ── 3. Initialisation Fiber ────────────────────────────────────────────────
	app := fiber.New(fiber.Config{
		// Nom de l'application — visible dans les logs et les réponses d'erreur
		AppName: "Suivi Projets Étudiants API v1.0",

		// Intercepte les panics Go et retourne un 500 propre
		// au lieu de crasher le serveur
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			code := fiber.StatusInternalServerError
			if e, ok := err.(*fiber.Error); ok {
				code = e.Code
			}
			return c.Status(code).JSON(fiber.Map{
				"success": false,
				"error":   err.Error(),
			})
		},
	})

	// ── 4. Middlewares globaux ─────────────────────────────────────────────────

	// Recover : transforme une panic en erreur 500 — évite le crash du serveur
	app.Use(recover.New())

	// Logger : affiche chaque requête dans la console
	// Format : méthode | url | statut | durée
	app.Use(logger.New(logger.Config{
		Format: "[${time}] ${method} ${path} → ${status} (${latency})\n",
	}))

	// ── 5. Enregistrement des routes ───────────────────────────────────────────
	routes.Register(app, database.DB)

	// ── 6. Démarrage du serveur ────────────────────────────────────────────────
	addr := ":" + cfg.Port
	log.Printf("🚀 Serveur démarré sur http://localhost%s", addr)
	log.Fatal(app.Listen(addr))
}
