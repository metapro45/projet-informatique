package middleware

// TODO Étape 3 : Implémenter le middleware d'authentification JWT Supabase.
//
// Ce fichier contiendra :
//   - JWTProtected()  : vérifie la présence et la validité du Bearer token Supabase
//   - RequireRole()   : vérifie que le rôle extrait du JWT correspond au rôle attendu
//
// Dépendances à ajouter dans go.mod lors de l'Étape 3 :
//   - github.com/golang-jwt/jwt/v5
//   - github.com/gofiber/fiber/v2
