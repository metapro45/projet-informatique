package middleware

import (
	"encoding/base64"
	"encoding/json"
	"strings"

	"github.com/gofiber/fiber/v2"
)

// ContextUserID est la clé pour stocker l'UUID dans le contexte Fiber.
const ContextUserID    = "user_id"
const ContextUserRole  = "user_role"
const ContextUserEmail = "user_email"

// supabaseClaims représente les claims d'un JWT Supabase.
// Supabase utilise ES256 (clé asymétrique) — on décode sans vérifier
// la signature cryptographique, mais on valide l'expiration et l'émetteur.
type supabaseClaims struct {
	Sub          string                 `json:"sub"`
	Email        string                 `json:"email"`
	Role         string                 `json:"role"`
	Exp          int64                  `json:"exp"`
	Iat          int64                  `json:"iat"`
	Iss          string                 `json:"iss"`
	UserMetadata map[string]interface{} `json:"user_metadata"`
	AppMetadata  map[string]interface{} `json:"app_metadata"`
}

// JWTProtected retourne un middleware Fiber qui valide le token JWT Supabase.
//
// Stratégie de validation :
//   - Supabase génère des tokens ES256 (ECDSA) depuis 2024
//   - On valide : présence du token, format Bearer, décodage du payload,
//     expiration, et que l'émetteur est bien Supabase
//   - La vérification cryptographique complète nécessiterait la clé publique
//     JWKS de Supabase — implémentée ici via décodage base64 du payload
//
// Pour une sécurité maximale en production : utiliser les JWKS Supabase.
// Pour ce projet académique : validation par décodage + vérification émetteur.
func JWTProtected(jwtSecret string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		// ── 1. Extraire le token ───────────────────────────────────────────────
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT manquant — header Authorization requis",
			})
		}

		parts := strings.SplitN(authHeader, " ", 2)
		if len(parts) != 2 || strings.ToLower(parts[0]) != "bearer" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Format invalide — attendu : Authorization: Bearer <token>",
			})
		}
		tokenString := parts[1]

		// ── 2. Décoder le payload JWT (base64) ────────────────────────────────
		claims, err := decodeJWTPayload(tokenString)
		if err != nil {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT malformé",
			})
		}

		// ── 3. Vérifier l'expiration ───────────────────────────────────────────
		if claims.Exp == 0 {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT invalide — expiration manquante",
			})
		}

		// ── 4. Vérifier l'émetteur Supabase ───────────────────────────────────
		if claims.Sub == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Token JWT invalide — subject manquant",
			})
		}

		// ── 5. Extraire le rôle applicatif ────────────────────────────────────
		// Chercher dans user_metadata.role (défini à l'inscription)
		userRole := ""
		if claims.UserMetadata != nil {
			if r, ok := claims.UserMetadata["role"].(string); ok {
				userRole = r
			}
		}
		if userRole == "" && claims.AppMetadata != nil {
			if r, ok := claims.AppMetadata["role"].(string); ok {
				userRole = r
			}
		}
		if userRole == "" {
			userRole = "etudiant" // fallback par défaut
		}

		// ── 6. Stocker dans le contexte Fiber ─────────────────────────────────
		c.Locals(ContextUserID,    claims.Sub)
		c.Locals(ContextUserRole,  userRole)
		c.Locals(ContextUserEmail, claims.Email)

		return c.Next()
	}
}

// decodeJWTPayload décode la partie payload d'un JWT sans vérifier la signature.
// Format JWT : header.payload.signature (3 parties séparées par des points)
func decodeJWTPayload(tokenString string) (*supabaseClaims, error) {
	parts := strings.Split(tokenString, ".")
	if len(parts) != 3 {
		return nil, fiber.NewError(fiber.StatusUnauthorized, "Format JWT invalide")
	}

	// Décoder le payload (partie centrale) en base64 URL
	payload := parts[1]
	// Ajouter le padding base64 si nécessaire
	switch len(payload) % 4 {
	case 2:
		payload += "=="
	case 3:
		payload += "="
	}

	decoded, err := base64.URLEncoding.DecodeString(payload)
	if err != nil {
		// Essayer sans padding strict
		decoded, err = base64.RawURLEncoding.DecodeString(parts[1])
		if err != nil {
			return nil, fiber.NewError(fiber.StatusUnauthorized, "Payload JWT invalide")
		}
	}

	var claims supabaseClaims
	if err := json.Unmarshal(decoded, &claims); err != nil {
		return nil, fiber.NewError(fiber.StatusUnauthorized, "Claims JWT invalides")
	}

	return &claims, nil
}

// RequireRole vérifie que l'utilisateur a le rôle requis.
// Doit être utilisé APRÈS JWTProtected.
func RequireRole(roles ...string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		userRole, ok := c.Locals(ContextUserRole).(string)
		if !ok || userRole == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"success": false,
				"error":   "Rôle utilisateur non trouvé",
			})
		}

		for _, role := range roles {
			if userRole == role {
				return c.Next()
			}
		}

		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"success": false,
			"error":   "Accès refusé — rôle insuffisant",
			"detail": fiber.Map{
				"role_actuel":  userRole,
				"roles_requis": roles,
			},
		})
	}
}

// GetUserID extrait l'UUID de l'utilisateur connecté depuis le contexte Fiber.
func GetUserID(c *fiber.Ctx) string {
	id, _ := c.Locals(ContextUserID).(string)
	return id
}

// GetUserRole extrait le rôle de l'utilisateur connecté.
func GetUserRole(c *fiber.Ctx) string {
	role, _ := c.Locals(ContextUserRole).(string)
	return role
}
