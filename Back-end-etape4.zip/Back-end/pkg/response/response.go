package response

import "github.com/gofiber/fiber/v2"

// Response est l'enveloppe JSON standard pour toutes les réponses de l'API.
// Chaque endpoint doit retourner cette structure pour garantir la cohérence
// avec le Front-end (Membre 2).
//
// Format de succès  : { "success": true,  "data": <payload> }
// Format d'erreur   : { "success": false, "error": "<message>" }
type Response struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
}

// OK envoie une réponse 200 avec un payload de données.
func OK(c *fiber.Ctx, data interface{}) error {
	return c.Status(fiber.StatusOK).JSON(Response{
		Success: true,
		Data:    data,
	})
}

// Created envoie une réponse 201 après création d'une ressource.
func Created(c *fiber.Ctx, data interface{}) error {
	return c.Status(fiber.StatusCreated).JSON(Response{
		Success: true,
		Data:    data,
	})
}

// BadRequest envoie une réponse 400 pour une requête invalide.
func BadRequest(c *fiber.Ctx, message string) error {
	return c.Status(fiber.StatusBadRequest).JSON(Response{
		Success: false,
		Error:   message,
	})
}

// Unauthorized envoie une réponse 401 pour un JWT manquant ou invalide.
func Unauthorized(c *fiber.Ctx, message string) error {
	return c.Status(fiber.StatusUnauthorized).JSON(Response{
		Success: false,
		Error:   message,
	})
}

// Forbidden envoie une réponse 403 pour un accès refusé (mauvais rôle).
func Forbidden(c *fiber.Ctx, message string) error {
	return c.Status(fiber.StatusForbidden).JSON(Response{
		Success: false,
		Error:   message,
	})
}

// NotFound envoie une réponse 404 pour une ressource introuvable.
func NotFound(c *fiber.Ctx, message string) error {
	return c.Status(fiber.StatusNotFound).JSON(Response{
		Success: false,
		Error:   message,
	})
}

// InternalError envoie une réponse 500 pour une erreur serveur.
func InternalError(c *fiber.Ctx, message string) error {
	return c.Status(fiber.StatusInternalServerError).JSON(Response{
		Success: false,
		Error:   message,
	})
}
