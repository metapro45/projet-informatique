package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// EquipeHandler regroupe les handlers HTTP pour la ressource Equipe.
// TODO Étape 4 : Implémenter chaque handler.
type EquipeHandler struct {
	db *sql.DB
}

func NewEquipeHandler(db *sql.DB) *EquipeHandler {
	return &EquipeHandler{db: db}
}

// GetByProjet godoc
// @Route GET /api/projets/:id/equipes
func (h *EquipeHandler) GetByProjet(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "GET /api/projets/:id/equipes — non implémenté (Étape 4)",
	})
}

// Create godoc
// @Route POST /api/projets/:id/equipes
func (h *EquipeHandler) Create(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "POST /api/projets/:id/equipes — non implémenté (Étape 4)",
	})
}

// Update godoc
// @Route PUT /api/equipes/:id
func (h *EquipeHandler) Update(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "PUT /api/equipes/:id — non implémenté (Étape 4)",
	})
}

// Delete godoc
// @Route DELETE /api/equipes/:id
func (h *EquipeHandler) Delete(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "DELETE /api/equipes/:id — non implémenté (Étape 4)",
	})
}
