package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// JalonHandler regroupe les handlers HTTP pour la ressource Jalon.
// TODO Étape 5 : Implémenter chaque handler.
type JalonHandler struct {
	db *sql.DB
}

func NewJalonHandler(db *sql.DB) *JalonHandler {
	return &JalonHandler{db: db}
}

// GetByProjet godoc
// @Route GET /api/projets/:id/jalons
func (h *JalonHandler) GetByProjet(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "GET /api/projets/:id/jalons — non implémenté (Étape 5)",
	})
}

// Create godoc
// @Route POST /api/projets/:id/jalons
func (h *JalonHandler) Create(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "POST /api/projets/:id/jalons — non implémenté (Étape 5)",
	})
}

// Update godoc
// @Route PUT /api/jalons/:id
func (h *JalonHandler) Update(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "PUT /api/jalons/:id — non implémenté (Étape 5)",
	})
}

// Delete godoc
// @Route DELETE /api/jalons/:id
func (h *JalonHandler) Delete(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "DELETE /api/jalons/:id — non implémenté (Étape 5)",
	})
}
