package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// MembreHandler regroupe les handlers HTTP pour la ressource Membre.
// TODO Étape 4 : Implémenter chaque handler.
type MembreHandler struct {
	db *sql.DB
}

func NewMembreHandler(db *sql.DB) *MembreHandler {
	return &MembreHandler{db: db}
}

// GetByEquipe godoc
// @Route GET /api/equipes/:id/membres
func (h *MembreHandler) GetByEquipe(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "GET /api/equipes/:id/membres — non implémenté (Étape 4)",
	})
}

// Add godoc
// @Route POST /api/equipes/:id/membres
func (h *MembreHandler) Add(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "POST /api/equipes/:id/membres — non implémenté (Étape 4)",
	})
}

// Remove godoc
// @Route DELETE /api/equipes/:id/membres/:user_id
func (h *MembreHandler) Remove(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "DELETE /api/equipes/:id/membres/:user_id — non implémenté (Étape 4)",
	})
}
