package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"

	"suivi-projets-backend/internal/domain"
	"suivi-projets-backend/internal/repository/postgres"
	"suivi-projets-backend/pkg/middleware"
)

// ProjetHandler gère les endpoints HTTP pour la ressource Projet.
// Contrat d'API : §2 — sections 2.1 à 2.5
type ProjetHandler struct {
	repo *postgres.ProjetRepository
}

// NewProjetHandler crée un ProjetHandler avec la connexion BDD injectée.
func NewProjetHandler(db *sql.DB) *ProjetHandler {
	return &ProjetHandler{
		repo: postgres.NewProjetRepository(db),
	}
}

// ── Structures de requête ─────────────────────────────────────────────────────

// createProjetRequest est le body attendu pour POST /api/projets
type createProjetRequest struct {
	Titre       string  `json:"titre"`
	Description *string `json:"description"`
	Statut      string  `json:"statut"`
	DateDebut   *string `json:"date_debut"`  // YYYY-MM-DD
	DateFin     *string `json:"date_fin"`     // YYYY-MM-DD
}

// updateProjetRequest est le body attendu pour PUT /api/projets/:id
type updateProjetRequest struct {
	Titre       string  `json:"titre"`
	Description *string `json:"description"`
	Statut      string  `json:"statut"`
	DateDebut   *string `json:"date_debut"`
	DateFin     *string `json:"date_fin"`
}

// ── 2.1 — GET /api/projets ────────────────────────────────────────────────────

// GetAll retourne la liste de tous les projets.
// Filtrage par rôle : un étudiant ne voit que les projets de ses équipes (Étape 8).
// Pour l'instant, retourne tous les projets.
func (h *ProjetHandler) GetAll(c *fiber.Ctx) error {
	projets, err := h.repo.GetAll(c.Context())
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la récupération des projets",
		})
	}

	// Retourner un tableau vide plutôt que null si aucun projet
	if projets == nil {
		projets = []*domain.Projet{}
	}

	return c.JSON(fiber.Map{
		"success": true,
		"data":    projets,
	})
}

// ── 2.2 — POST /api/projets ───────────────────────────────────────────────────

// Create crée un nouveau projet.
// L'enseignant_id est extrait du JWT — le Frontend n'a pas à l'envoyer.
func (h *ProjetHandler) Create(c *fiber.Ctx) error {
	// Parser le body
	var req createProjetRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Body JSON invalide",
		})
	}

	// Validation
	if req.Titre == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Le champ 'titre' est obligatoire",
		})
	}
	statuts := map[string]bool{"actif": true, "archive": true, "termine": true}
	if !statuts[req.Statut] {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Statut invalide — valeurs acceptées : actif | archive | termine",
		})
	}

	// Extraire l'enseignant_id depuis le JWT
	enseignantIDStr := middleware.GetUserID(c)
	enseignantID, err := uuid.Parse(enseignantIDStr)
	if err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"success": false,
			"error":   "Impossible d'extraire l'identifiant utilisateur du token",
		})
	}

	// Construire l'entité
	projet := &domain.Projet{
		Titre:        req.Titre,
		Description:  req.Description,
		Statut:       domain.StatutProjet(req.Statut),
		EnseignantID: &enseignantID,
	}

	// Parser les dates optionnelles
	if req.DateDebut != nil && *req.DateDebut != "" {
		d := &domain.Date{}
		if err := d.UnmarshalJSON([]byte(`"` + *req.DateDebut + `"`)); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"success": false,
				"error":   "Format date_debut invalide — attendu : YYYY-MM-DD",
			})
		}
		projet.DateDebut = d
	}
	if req.DateFin != nil && *req.DateFin != "" {
		d := &domain.Date{}
		if err := d.UnmarshalJSON([]byte(`"` + *req.DateFin + `"`)); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"success": false,
				"error":   "Format date_fin invalide — attendu : YYYY-MM-DD",
			})
		}
		projet.DateFin = d
	}

	// Insérer en base
	if err := h.repo.Create(c.Context(), projet); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la création du projet",
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"success": true,
		"data":    projet,
	})
}

// ── 2.3 — GET /api/projets/:id ────────────────────────────────────────────────

// GetByID retourne un projet par son UUID.
func (h *ProjetHandler) GetByID(c *fiber.Ctx) error {
	id, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "L'identifiant du projet est invalide (UUID attendu)",
		})
	}

	projet, err := h.repo.GetByID(c.Context(), id)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la récupération du projet",
		})
	}
	if projet == nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"success": false,
			"error":   "Projet introuvable",
		})
	}

	return c.JSON(fiber.Map{
		"success": true,
		"data":    projet,
	})
}

// ── 2.4 — PUT /api/projets/:id ────────────────────────────────────────────────

// Update met à jour un projet existant.
// Seul l'enseignant propriétaire peut modifier son projet.
func (h *ProjetHandler) Update(c *fiber.Ctx) error {
	id, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "L'identifiant du projet est invalide",
		})
	}

	// Vérifier que le projet existe et appartient à cet enseignant
	projet, err := h.repo.GetByID(c.Context(), id)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la vérification du projet",
		})
	}
	if projet == nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"success": false,
			"error":   "Projet introuvable",
		})
	}

	// Vérifier que c'est bien le propriétaire
	userID := middleware.GetUserID(c)
	if projet.EnseignantID == nil || projet.EnseignantID.String() != userID {
		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"success": false,
			"error":   "Vous n'êtes pas le propriétaire de ce projet",
		})
	}

	// Parser le body
	var req updateProjetRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Body JSON invalide",
		})
	}

	// Validation
	if req.Titre == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Le champ 'titre' est obligatoire",
		})
	}
	statuts := map[string]bool{"actif": true, "archive": true, "termine": true}
	if !statuts[req.Statut] {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "Statut invalide — valeurs acceptées : actif | archive | termine",
		})
	}

	// Mettre à jour l'entité
	projet.Titre       = req.Titre
	projet.Description = req.Description
	projet.Statut      = domain.StatutProjet(req.Statut)
	projet.DateDebut   = nil
	projet.DateFin     = nil

	if req.DateDebut != nil && *req.DateDebut != "" {
		d := &domain.Date{}
		if err := d.UnmarshalJSON([]byte(`"` + *req.DateDebut + `"`)); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"success": false,
				"error":   "Format date_debut invalide",
			})
		}
		projet.DateDebut = d
	}
	if req.DateFin != nil && *req.DateFin != "" {
		d := &domain.Date{}
		if err := d.UnmarshalJSON([]byte(`"` + *req.DateFin + `"`)); err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
				"success": false,
				"error":   "Format date_fin invalide",
			})
		}
		projet.DateFin = d
	}

	if err := h.repo.Update(c.Context(), projet); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la mise à jour du projet",
		})
	}

	return c.JSON(fiber.Map{
		"success": true,
		"data":    projet,
	})
}

// ── 2.5 — DELETE /api/projets/:id ────────────────────────────────────────────

// Delete supprime un projet.
// Seul l'enseignant propriétaire peut supprimer son projet.
func (h *ProjetHandler) Delete(c *fiber.Ctx) error {
	id, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"success": false,
			"error":   "L'identifiant du projet est invalide",
		})
	}

	// Vérifier que le projet existe et appartient à cet enseignant
	projet, err := h.repo.GetByID(c.Context(), id)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la vérification du projet",
		})
	}
	if projet == nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"success": false,
			"error":   "Projet introuvable",
		})
	}

	// Vérifier propriété
	userID := middleware.GetUserID(c)
	if projet.EnseignantID == nil || projet.EnseignantID.String() != userID {
		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"success": false,
			"error":   "Vous n'êtes pas le propriétaire de ce projet",
		})
	}

	if err := h.repo.Delete(c.Context(), id); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"success": false,
			"error":   "Erreur lors de la suppression du projet",
		})
	}

	return c.Status(fiber.StatusNoContent).Send(nil)
}
