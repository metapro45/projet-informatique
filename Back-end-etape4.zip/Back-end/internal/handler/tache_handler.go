package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// TacheHandler regroupe les handlers HTTP pour la ressource Tache (Kanban).
// TODO Étape 5 : Implémenter chaque handler.
type TacheHandler struct {
	db *sql.DB
}

func NewTacheHandler(db *sql.DB) *TacheHandler {
	return &TacheHandler{db: db}
}

// GetByEquipe godoc
// @Route GET /api/equipes/:id/taches
func (h *TacheHandler) GetByEquipe(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "GET /api/equipes/:id/taches — non implémenté (Étape 5)",
	})
}

// Create godoc
// @Route POST /api/equipes/:id/taches
func (h *TacheHandler) Create(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "POST /api/equipes/:id/taches — non implémenté (Étape 5)",
	})
}

// UpdateStatut godoc
// @Route    PATCH /api/taches/:id/statut
// @Critical Endpoint du drag-and-drop Kanban — Étape 5 & 9
func (h *TacheHandler) UpdateStatut(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "PATCH /api/taches/:id/statut — non implémenté (Étape 5)",
	})
}

// Update godoc
// @Route PATCH /api/taches/:id
func (h *TacheHandler) Update(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "PATCH /api/taches/:id — non implémenté (Étape 5)",
	})
}

// Delete godoc
// @Route DELETE /api/taches/:id
func (h *TacheHandler) Delete(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "DELETE /api/taches/:id — non implémenté (Étape 5)",
	})
}
