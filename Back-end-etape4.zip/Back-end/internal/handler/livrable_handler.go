package handler

import (
	"database/sql"

	"github.com/gofiber/fiber/v2"
)

// LivrableHandler regroupe les handlers HTTP pour la ressource Livrable.
// TODO Étape 6 : Implémenter chaque handler + passerelle Supabase Storage.
type LivrableHandler struct {
	db *sql.DB
}

func NewLivrableHandler(db *sql.DB) *LivrableHandler {
	return &LivrableHandler{db: db}
}

// GetByJalon godoc
// @Route GET /api/jalons/:id/livrables
func (h *LivrableHandler) GetByJalon(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "GET /api/jalons/:id/livrables — non implémenté (Étape 6)",
	})
}

// Create godoc
// @Route POST /api/equipes/:id/livrables
func (h *LivrableHandler) Create(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "POST /api/equipes/:id/livrables — non implémenté (Étape 6)",
	})
}

// Noter godoc
// @Route PATCH /api/livrables/:id/note
func (h *LivrableHandler) Noter(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "PATCH /api/livrables/:id/note — non implémenté (Étape 6)",
	})
}

// Delete godoc
// @Route DELETE /api/livrables/:id
func (h *LivrableHandler) Delete(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{
		"success": false, "error": "DELETE /api/livrables/:id — non implémenté (Étape 6)",
	})
}
