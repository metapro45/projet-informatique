package postgres

import (
	"context"
	"database/sql"
	"fmt"

	"github.com/google/uuid"

	"suivi-projets-backend/internal/domain"
)

// ProjetRepository implémente repository.ProjetRepository via PostgreSQL.
type ProjetRepository struct {
	db *sql.DB
}

func NewProjetRepository(db *sql.DB) *ProjetRepository {
	return &ProjetRepository{db: db}
}

const sqlGetAllProjets = `
	SELECT id, titre, description, statut,
	       date_debut, date_fin, enseignant_id, created_at
	FROM projets
	ORDER BY created_at DESC
`
const sqlGetProjetByID = `
	SELECT id, titre, description, statut,
	       date_debut, date_fin, enseignant_id, created_at
	FROM projets WHERE id = $1
`
const sqlCreateProjet = `
	INSERT INTO projets (id, titre, description, statut, date_debut, date_fin, enseignant_id)
	VALUES ($1, $2, $3, $4, $5, $6, $7)
	RETURNING id, titre, description, statut, date_debut, date_fin, enseignant_id, created_at
`
const sqlUpdateProjet = `
	UPDATE projets
	SET titre=$2, description=$3, statut=$4, date_debut=$5, date_fin=$6
	WHERE id = $1
	RETURNING id, titre, description, statut, date_debut, date_fin, enseignant_id, created_at
`

func (r *ProjetRepository) GetAll(ctx context.Context) ([]*domain.Projet, error) {
	rows, err := r.db.QueryContext(ctx, sqlGetAllProjets)
	if err != nil {
		return nil, fmt.Errorf("projet.GetAll: %w", err)
	}
	defer rows.Close()

	var projets []*domain.Projet
	for rows.Next() {
		p, err := scanProjet(rows)
		if err != nil {
			return nil, fmt.Errorf("projet.GetAll scan: %w", err)
		}
		projets = append(projets, p)
	}
	return projets, nil
}

func (r *ProjetRepository) GetByID(ctx context.Context, id uuid.UUID) (*domain.Projet, error) {
	row := r.db.QueryRowContext(ctx, sqlGetProjetByID, id)
	p, err := scanProjetRow(row)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("projet.GetByID: %w", err)
	}
	return p, nil
}

func (r *ProjetRepository) Create(ctx context.Context, projet *domain.Projet) error {
	projet.ID = uuid.New()
	row := r.db.QueryRowContext(ctx, sqlCreateProjet,
		projet.ID, projet.Titre, projet.Description,
		projet.Statut, projet.DateDebut, projet.DateFin, projet.EnseignantID,
	)
	created, err := scanProjetRow(row)
	if err != nil {
		return fmt.Errorf("projet.Create: %w", err)
	}
	*projet = *created
	return nil
}

func (r *ProjetRepository) Update(ctx context.Context, projet *domain.Projet) error {
	row := r.db.QueryRowContext(ctx, sqlUpdateProjet,
		projet.ID, projet.Titre, projet.Description,
		projet.Statut, projet.DateDebut, projet.DateFin,
	)
	updated, err := scanProjetRow(row)
	if err == sql.ErrNoRows {
		return fmt.Errorf("projet.Update: projet %s introuvable", projet.ID)
	}
	if err != nil {
		return fmt.Errorf("projet.Update: %w", err)
	}
	*projet = *updated
	return nil
}

// Delete supprime un projet et toutes ses dépendances dans l'ordre correct.
// Ordre de suppression : taches → membres → livrables → jalons → equipes → projet
// On utilise une transaction pour garantir l'atomicité.
func (r *ProjetRepository) Delete(ctx context.Context, id uuid.UUID) error {
	tx, err := r.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("projet.Delete begin tx: %w", err)
	}
	defer tx.Rollback()

	// 1. Supprimer les tâches des équipes de ce projet
	_, err = tx.ExecContext(ctx, `
		DELETE FROM taches
		WHERE equipe_id IN (
			SELECT id FROM equipes WHERE projet_id = $1
		)
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete taches: %w", err)
	}

	// 2. Supprimer les livrables des équipes de ce projet
	_, err = tx.ExecContext(ctx, `
		DELETE FROM livrables
		WHERE equipe_id IN (
			SELECT id FROM equipes WHERE projet_id = $1
		)
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete livrables: %w", err)
	}

	// 3. Supprimer les membres des équipes de ce projet
	_, err = tx.ExecContext(ctx, `
		DELETE FROM membres
		WHERE equipe_id IN (
			SELECT id FROM equipes WHERE projet_id = $1
		)
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete membres: %w", err)
	}

	// 4. Supprimer les équipes du projet
	_, err = tx.ExecContext(ctx, `
		DELETE FROM equipes WHERE projet_id = $1
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete equipes: %w", err)
	}

	// 5. Supprimer les jalons du projet
	_, err = tx.ExecContext(ctx, `
		DELETE FROM jalons WHERE projet_id = $1
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete jalons: %w", err)
	}

	// 6. Supprimer le projet lui-même
	result, err := tx.ExecContext(ctx, `
		DELETE FROM projets WHERE id = $1
	`, id)
	if err != nil {
		return fmt.Errorf("projet.Delete projet: %w", err)
	}

	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("projet.Delete: projet %s introuvable", id)
	}

	return tx.Commit()
}

// ── Helpers de scan ───────────────────────────────────────────────────────────

type scanRow interface {
	Scan(dest ...interface{}) error
}

func scanProjet(rows *sql.Rows) (*domain.Projet, error) {
	return scanProjetFields(rows)
}

func scanProjetRow(row *sql.Row) (*domain.Projet, error) {
	return scanProjetFields(row)
}

func scanProjetFields(s scanRow) (*domain.Projet, error) {
	p := &domain.Projet{}
	var description sql.NullString
	var dateDebut, dateFin sql.NullTime
	var enseignantID uuid.NullUUID
	var createdAt sql.NullTime

	err := s.Scan(
		&p.ID, &p.Titre, &description, &p.Statut,
		&dateDebut, &dateFin, &enseignantID, &createdAt,
	)
	if err != nil {
		return nil, err
	}

	if description.Valid {
		p.Description = &description.String
	}
	if dateDebut.Valid {
		d := domain.Date{Time: dateDebut.Time}
		p.DateDebut = &d
	}
	if dateFin.Valid {
		d := domain.Date{Time: dateFin.Time}
		p.DateFin = &d
	}
	if enseignantID.Valid {
		p.EnseignantID = &enseignantID.UUID
	}
	if createdAt.Valid {
		t := createdAt.Time.UTC()
		p.CreatedAt = &t
	}
	return p, nil
}
