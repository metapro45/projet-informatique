package domain

import (
	"time"

	"github.com/google/uuid"
)

// RoleUtilisateur représente les deux profils possibles dans le système.
// Valeurs attendues en BDD : "etudiant" | "enseignant"
type RoleUtilisateur string

const (
	RoleEtudiant   RoleUtilisateur = "etudiant"
	RoleEnseignant RoleUtilisateur = "enseignant"
)

// User mappe la table `public.users` de Supabase.
// L'authentification est déléguée à Supabase Auth (JWT).
// Ce modèle représente le profil applicatif étendu de l'utilisateur.
type User struct {
	ID        uuid.UUID       `json:"id" db:"id"`
	Email     string          `json:"email" db:"email"`
	Nom       string          `json:"nom" db:"nom"`
	Prenom    *string         `json:"prenom,omitempty" db:"prenom"`
	Role      RoleUtilisateur `json:"role" db:"role"`
	CreatedAt *time.Time      `json:"created_at,omitempty" db:"created_at"`
}
