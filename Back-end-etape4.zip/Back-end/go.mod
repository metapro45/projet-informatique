module suivi-projets-backend

go 1.26.3

require (
	github.com/gofiber/fiber/v2 v2.52.5
	github.com/google/uuid v1.6.0
	github.com/lib/pq v1.10.9
)
